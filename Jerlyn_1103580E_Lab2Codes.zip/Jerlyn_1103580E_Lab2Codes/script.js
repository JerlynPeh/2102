// Code goes here

var mainApp = angular.module("mainApp", ['ngRoute']);
 
mainApp.config(function($routeProvider) {
    $routeProvider
        .when('/home', {
            templateUrl: 'home.html',
            controller: 'StudentController'
        })
        .when('/viewAll', {
            templateUrl: 'viewAll.html',
            controller: 'StudentController'
        })
        
        .when('/filterGender', {
            templateUrl: 'filterGender.html',
            controller: 'StudentController'
        })
        
         .when('/lowerCase', {
            templateUrl: 'lowerCase.html',
            controller: 'StudentController'
        })
        
         .when('/searchFilter', {
            templateUrl: 'searchFilter.html',
            controller: 'StudentController'
        })
        

        .otherwise({
            redirectTo: '/home'
        });
});
 
mainApp.controller('StudentController', function($scope) {
  $scope.sit = {imageSrc: "http://chezabelll.com/wp-content/uploads/2014/09/logo2.jpg"};
    $scope.students = [
        {name: 'Mark Waugh', age:'12', gender:'M'},
        {name: 'Steve Jonathan', age:'31', gender:'M'},
        {name: 'John Marcus', age:'22', gender:'M'},
        {name: 'Paty Kerry', age:'34', gender:'F'},
        {name: 'Saylor Twift', age:'56', gender:'F'},
        {name: 'Katie Marcus', age:'11', gender:'F'}
    ];
    $scope.message1 = "Hi there! A warm welcome to my very first angularjs page. Enjoy this simple website :)";
 
    $scope.message2 = "Click on the hyper link to view the students list.";
});